package Pro;
public class ExponentialSearch {

    public static int exponentialSearch(int[] arr, int value) {
        if (arr[0] == value) {
            return 0; // Element found at the first position
        }

        int i = 1;
        while (i < arr.length && arr[i] <= value) {
            i *= 2;
        }

        // Perform binary search in the identified range
        return binarySearch(arr, value, i / 2, Math.min(i, arr.length - 1));
    }

    private static int binarySearch(int[] arr, int value, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == value) {
                return mid; // Element found, return its index
            } else if (arr[mid] < value) {
                left = mid + 1; // Search the right half
            } else {
                right = mid - 1; // Search the left half
            }
        }

        return -1; // Element not found
    }

    public static void main(String[] args) {
        int[] array = {12,24,36,28,60,72,84,96};
        int findvalue= 24;

        int result = exponentialSearch(array, findvalue);

        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}

