package Com.emailvalidation;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ErrorServlet")
public class ErrorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Display error message
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Error</title></head><body>");
        out.println("<h1>Invalid Login</h1>");
        out.println("<p>Please check your email and password.</p>");
        out.println("<a href='login.html'>Go back to Login</a>");
        out.println("</body></html>");
    }
}


