package javafsd;

class Node {
    int data;
    Node prev, next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedListTraversal {
    public static void main(String[] args) {
        Node head = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);

        // Connect nodes to form a doubly linked list
        head.next = second;
        second.prev = head;
        second.next = third;
        third.prev = second;
        third.next = fourth;
        fourth.prev = third;

        // Traverse in forward direction
        System.out.println("Forward Traversal:");
        Node currentForward = head;
        while (currentForward != null) {
            System.out.print(currentForward.data + " ");
            currentForward = currentForward.next;
        }
        System.out.println();

        // Traverse in backward direction
        System.out.println("Backward Traversal:");
        Node currentBackward = fourth;
        while (currentBackward != null) {
            System.out.print(currentBackward.data + " ");
            currentBackward = currentBackward.prev;
        }
        System.out.println();
    }
}
