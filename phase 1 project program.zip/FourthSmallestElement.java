package com;

import java.util.Arrays;
import java.util.Scanner;

public class FourthSmallestElement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements of the list:");

        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element is: " + fourthSmallest);

        scanner.close();
    }

    static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List should have at least 4 elements");
            return -1;
        }

        Arrays.sort(arr);

        
        return arr[3];
    }
}


