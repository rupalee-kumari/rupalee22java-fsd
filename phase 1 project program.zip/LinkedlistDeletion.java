package com;

	class Node {
	    int data;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class LinkedList {
	    Node head;

	    
	    void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node temp = head;
	            while (temp.next != null) {
	                temp = temp.next;
	            }
	            temp.next = newNode;
	        }
	    }

	    void deleteNode(int key) {
	        Node current = head;
	        Node prev = null;

	        if (current != null && current.data == key) {
	            head = current.next;
	            return;
	        }

	        
	        while (current != null && current.data != key) {
	            prev = current;
	            current = current.next;
	        }

	        
	        if (current == null) {
	            System.out.println("Key not found in the linked list.");
	            return;
	        }

	       
	        prev.next = current.next;
	    }

	    
	    void displayList() {
	        Node temp = head;
	        while (temp != null) {
	            System.out.print(temp.data + " ");
	            temp = temp.next;
	        }
	        System.out.println();
	    }
	}

	public class LinkedlistDeletion  {
	    public static void main(String[] args) {
	        LinkedList linkedList = new LinkedList();

	      
	        linkedList.insert(1);
	        linkedList.insert(2);
	        linkedList.insert(3);
	        linkedList.insert(4);
	        linkedList.insert(5);

	        System.out.println("Original Linked List:");
	        linkedList.displayList();

	        int keyToDelete = 3;
	        linkedList.deleteNode(keyToDelete);

	        System.out.println("Linked List after deleting first occurrence of " + keyToDelete + ":");
	        linkedList.displayList();
	    }
	}
