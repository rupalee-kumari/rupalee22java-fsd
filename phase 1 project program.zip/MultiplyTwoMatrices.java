package com;

public class MultiplyTwoMatrices{  
public static void main(String args[]){     
int a[][]={{1,0,1},{2,2,0},{0,3,3}};    
int b[][]={{1,1,0},{2,0,2},{3,3,0}};    
    
//this matrix to store the multiplication of two matrices    
int c[][]=new int[3][3];    
for(int i=0;i<3;i++){    
for(int j=0;j<3;j++){    
c[i][j]=0;      
for(int k=0;k<3;k++)      
{      
c[i][j]+=a[i][k]*b[k][j];      
} 
System.out.print(c[i][j]+" ");  //printing matrix element  
} 
System.out.println();//new line    
}    
} 
	}


