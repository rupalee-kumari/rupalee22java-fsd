package com;
import java.util.LinkedList;
import java.util.Queue;

public class  QueuePerform {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        System.out.println("Inserting elements into the queue:");
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.add(40);
        printQueue(queue);
        System.out.println("\nRemoving elements from the queue:");
        int removedElement = queue.poll();
        System.out.println("Removed Element: " + removedElement);
        printQueue(queue);
    }

    // Method to display the elements of the queue
    private static void printQueue(Queue<Integer> queue) {
        System.out.print("Queue: ");
        for (Integer element : queue) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}


