package com;
import java.util.Stack;

public class StackPerform{
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        System.out.print(stack);

        System.out.println("\nRemoving elements from the stack:");
        int poppedElement = stack.pop();
        System.out.println("Popped Element: " + poppedElement);

        System.out.print(stack);
    }
    public static void main(Stack<Integer> stack) {
        System.out.print("Stack: ");
        for (Integer element : stack) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}



	