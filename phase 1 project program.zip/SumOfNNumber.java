package com;
	import java.util.Scanner;

	public class SumOfNNumber {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the number of elements (n): ");
	        int n = scanner.nextInt();
	        if (n <= 0) {
	            System.out.println("Invalid input. Please enter a positive integer for n.");
	            return;
	        }

	        int[] array = new int[n];

	        System.out.println("Enter the elements of the array:");
	        for (int i = 0; i < n; i++) {
	            System.out.print("Enter element " + i + ": ");
	            array[i] = scanner.nextInt();
	        }

	        System.out.print("Enter the value of L (0 <= L <= n-1): ");
	        int L = scanner.nextInt();
	        System.out.print("Enter the value of R (L <= R <= n-1): ");
	        int R = scanner.nextInt();
	        if (L < 0 || R >= n || L > R) {
	            System.out.println("Invalid input. Ensure 0 <= L <= R <= n-1.");
	            return;
	        }

	        int sum = calculateSumInRange(array, L, R);

	        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);

	        scanner.close();
	    }

	    static int calculateSumInRange(int[] array, int L, int R) {
	        int sum = 0;
	        for (int i = L; i <= R; i++) {
	            sum += array[i];
	        }
	        return sum;
	    }
	

	}


