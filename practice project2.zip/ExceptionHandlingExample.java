
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}
public class ExceptionHandlingExample {
    public static void main(String[] args) throws InterruptedException {
        for(int i=1;i<=5;i++){
            System.out.println(i);
        }
        String str = null;
        try {
            System.out.println(str.toUpperCase());
        } catch (NullPointerException n) {
            System.out.println("null can't be casted");

        } finally {
            System.out.println("Program execution complete.");

        }
    }
}



