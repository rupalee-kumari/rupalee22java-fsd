import java.io.*;
public class FileHandlingDemo {
        public static void main(String[] args) {
            // Create a file
            try {
                File file = new File("example.txt");
                if (file.createNewFile()) {
                    System.out     .println("File created: " + file.getName());
                } else {
                    System     .out.println("File already exists.");
                }
            } catch (IOException e) {
                System.out.println("Error creating file: " + e.getMessage());
            }

            // Read from a file
            try {
                FileReader f1 = new FileReader("example.txt");
                BufferedReader b1 = new BufferedReader(f1);
                String line;
                while ((line = b1.readLine()) != null) {
                    System.out.println(line);
                }
                b1.close();
            } catch (IOException e) {
                System.out.println( e.getMessage());
            }

            // Update a file
            try {
                FileWriter f1 = new FileWriter("example.txt", true);
                BufferedWriter b1 = new BufferedWriter(f1);
                b1.write("This is a new line.");
                b1.newLine();
                b1.close();
                System.out.println("File updated successfully.");
            } catch (IOException e) {
                System.out.println("Error updating file: " + e.getMessage());
            }

            // Delete a file
            try {
                File file = new File("example.txt");
                if (file.delete()) {
                    System.out.println("File deleted successfully.");
                } else {
                    System.out.println("Error deleting file.");
                }
            } catch (SecurityException e) {
                System.out.println("Error deleting file: " + e.getMessage());
            }
        }
    }

