   class Car {
        private String name;
        private String model;
        private int prize;
        private boolean engineStatus;

        // Constructor
        public Car(String name, String model, int prize) {
            this.name = name;
            this.model = model;
            this.prize = prize;
            this.engineStatus = false;
            System.out.println(name);
            System.out.println(model);
            System.out.println(prize);;
        }

        // Methods
        public void start() {
            engineStatus = true;
            System.out.println("Car started.");
        }

        public void stop() {
            engineStatus = false;
            System.out.println("Car stopped.");
        }

        public void accelerate() {
            if (engineStatus) {
                System.out.println("Car is accelerating.");
            } else {
                System.out.println("Please start the car first.");
            }
        }
    }
   public class ObjectOriented {
       public static void main(String[] args) {
           // object of car
           Car myCar = new Car("Suzuki", "Ertiga", 900000 );
           myCar.start();
           myCar.accelerate();
           myCar.stop();
       }
   }

