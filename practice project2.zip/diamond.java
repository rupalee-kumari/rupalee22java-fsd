 class Animal {
    void walk() {
        System.out.println("This animal can walk");
    }

}
class Horse extends Animal {
    void walk() {
        System.out.println("Horse walks on 4 legs");
    }
}


class Chicken extends Animal {
    Chicken() {
        System.out.println("Chicken!");
    }
    void walk() {
        System.out.println("Chicken walks on 2 legs");
    }
}


public class diamond {
    public static void main(String args[]) {
        Horse horse = new Horse();
        horse.walk();
    }
}
