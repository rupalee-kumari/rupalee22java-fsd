import java.util.Scanner;
public class exceptionhandling{
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            try {
                System.out.print("Enter a number: ");
                int n1= scanner.nextInt();

                System.out.print("Enter second number: ");
                int d1= scanner.nextInt();

                int result = divideNumbers(n1, d1);
                System.out.println("Result of division: " + result);
            } catch (ArithmeticException e) {
                System.out.println("Error: Cannot divide by zero. Please enter a non-zero denominator.");
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            } finally {
                System.out.println("Program execution complete.");
            }
        }

        private static int divideNumbers(int n1, int d1) {
            if (d1 == 0) {
                throw new ArithmeticException("Cannot divide by zero.");
            }
            return n1/ d1;
        }
    }


