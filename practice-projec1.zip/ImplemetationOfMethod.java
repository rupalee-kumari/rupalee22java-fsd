public class ImplemetationOfMethod {
        //method to calculate sum of two numbers -num1&num2
        public static int sum(int num1,int num2) {
            //public static void sum(num1,num2)


            int sum=num1+num2;
            return sum;
            //System.out.println(sum)

        }

        public static void main(String[] args) {

            System.out.println(sum(2,7));
//		 num1=2;
//		num2=7;
            //sum(num1 , num2) function call

        }

    }

